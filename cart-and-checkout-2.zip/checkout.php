<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Checkout</title>
  <link rel="stylesheet" href="cart.css">
</head>
<body>
  <h1>Checkout</h1>
  <form id="checkoutForm" action="order_placement.php" method="POST">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="phone">Phone:</label>
    <input type="text" id="phone" name="phone" required maxlength="10" minlength="10">  <!--PHONE HERE-->

    <label for="address">Address:</label>
    <textarea id="address" name="address" required></textarea>    <!--ADDRESS HERE-->

    <div class="row justify-content-center">
      <div class="col-lg-12">
        <div class="card">
          <div class="row">
            <div class="col-lg-3 radio-group">
              
              <div class="row d-flex px-3 radio" style="cursor: pointer;" onclick="selectPaymentOption(0)">
                <img class="pay" src="https://i.imgur.com/WIAP9Ku.jpg">
                <p class="my-auto">Credit Card</p>
              </div>
              <div class="row d-flex px-3 radio gray" style="cursor: pointer;" onclick="selectPaymentOption(1)">
                <img class="pay" src="https://i.imgur.com/OdL0XPt.jpg">
                <p class="my-auto">PayPal</p>
              </div>
              <div class="row d-flex px-3 radio" style="cursor: pointer;" onclick="selectPaymentOption(2)">
                <img class="pay" src="https://i.imgur.com/cMgjzdE.jpg">
                <p class="my-auto">Apple Pay</p>
              </div>

              <script>
                function selectPaymentOption(optionIndex) {
                  var radioButtons = document.getElementsByClassName("radio");
                  for (var i = 0; i < radioButtons.length; i++) {
                    var radioButton = radioButtons[i];
                    if (i === optionIndex) {
                      radioButton.style.backgroundColor = "lightgray";
                    } else {
                      radioButton.style.backgroundColor = "";
                    }
                    radioButton.onclick = function() {
                      return false;
                    };
                  }
                }
              </script>


            <div class="col-lg-5">
              <div class="row px-2">
                <label class="mb-1">
                  <h6 class="mb-0 text-sm">Card Number</h6>
                </label>
                <input class="mb-4" type="text" id="cnum" name="cardnumber" placeholder="Enter your card number" required maxlength="15">
                <div class="row">
                  <div class="col-lg-6">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">Expiration Date</h6>
                    </label>
                    <input class="mb-4" type="text" id="exp" name="expdate" placeholder="MM/YYYY" required maxlength="6">
                  </div>
                  <div class="col-lg-6">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">CVV</h6>
                    </label>
                    <input class="mb-4" type="text" id="cvv" name="cvv" placeholder="CVV" required maxlength="3">
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <input type="checkbox" class="checkbox" required>
                    <label>By clicking on "Place Order" below, you are confirming that you have read and agree to the Terms of Use and Privacy Policy.</label>
                  </div>
                </div>
                <button type="submit" id="checkout" class="btn btn-primary btn-block py-2">Place Order</button>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="row px-2">
                <label class="mb-1">
                  <h6 class="mb-0 text-sm">Order Payment</h6>
                </label>
                <div class="row">
                  <div class="col-lg-6 mb-1">
                    <h6 class="mb-0">Subtotal: R</h6>
                  </div>
                  <div class="col-lg-6 mb-1">
                    <h6 class="mb-0" id="subtotal">0.00</h6>  <!--SUBTOTAL SHOULD BE HERE-->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  <!-- <script src="order_placement_script.js"></script> -->
  <script src="Cart.js"></script>
</body>
</html>
