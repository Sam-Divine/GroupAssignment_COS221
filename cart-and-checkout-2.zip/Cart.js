    const formData = {
       
        phone: "0800200300",
        address: "Pretoria"
      
      };

    // //create JSON from user input from the checkout page
    // const formData = {
       
    //     phone: document.getElementById("phone").value,
    //     address: document.getElementById("address").value
      
    //   };


    //remove the cartItem from the html table
    function removeItem(){
        let table = $('#table');
        $(document).on('click', '.remove-btn', function() {
            let rowid = $(this).closest('tr').data('index');
            table.bootstrapTable('remove', {
              field: '$index',
              values: [rowid]
            });
        });
    }

    // //Calculates the price
    // function calculatePrice(){
    //   const price = document.getElementsById("price").innerText
    // }

    // // Function to calculate the subtotal of the cart
    // function calculateSubtotal() {
    //     const subtotalTag = document.getElementById("subtotal");    //where the subtotal should display
    //   let subtotal = 0;


    //   for (const item of cartItems) {
    //     subtotal += item.price * item.quantity;
    //   }

    //   subtotalTag.innerHTML = subtotal; //DISPLAY
    // }
