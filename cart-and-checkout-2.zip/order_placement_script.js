

fetch('order_placement.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(orderData)
})
    .then(function (response) {
        if (response.ok) {
            return response.json();
        } else {
            throw new Error('Request failed. Status:', response.status);
        }
    })
    .then(function (responseData) {

            console.log("User ID: " + responseData.user_id);
            console.log("Wine ID: " + responseData.user_id);
            console.log("Quantity: " + responseData.quantity);
        // var dataContainer = document.getElementById('whateverID');


        // var userIdElement = document.createElement('p');
        // userIdElement.textContent = 'User ID: ' + orderData.user_id;

        // var customerIdElement = document.createElement('p');
        // customerIdElement.textContent = 'Customer ID: ' + orderData.customer_id;

        // var wineIdElement = document.createElement('p');
        // wineIdElement.textContent = 'Wine ID: ' + orderData.wine_id;

        // var quantityElement = document.createElement('p');
        // quantityElement.textContent = 'Quantity: ' + orderData.quantity;

        // var receivedElement = document.createElement('p');
        // receivedElement.textContent = 'Received: ' + orderData.received;


        // dataContainer.appendChild(userIdElement);
        // dataContainer.appendChild(customerIdElement);
        // dataContainer.appendChild(wineIdElement);
        // dataContainer.appendChild(quantityElement);
        // dataContainer.appendChild(receivedElement);

    })
    .catch(function (error) {
        console.log('Error:', error.message);
    });


/*var orderData = {
    user_id: '1',
    customer_id: '7',
    wine_id: '33',
    quantity: 1,
    received: 0
};
*/

