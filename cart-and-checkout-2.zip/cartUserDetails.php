<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    
    
    <script>
    function showInputField() {
    var selection = document.getElementById("selection").value;
    document.getElementById("age").style.display = (selection === "Age") ? "block" : "none";
    document.getElementById("companyname").style.display = (selection === "companyName") ? "block" : "none";
    }
</script>
    
</head>

<body>
    <div class="Container">
        <form action="order_placement.php" method="POST">
            <div>
                <input type="text" name="address" placeholder="Enter your address">
            </div>
            <div>
                <input type="text" name="phoneNumber" placeholder="Phone number:">
            </div>
            <label for="selection">Choose an option:</label>
            <select name="selection" id="selection" onchange="showInputField()">
                <option value="">Select an option</option>
                <option value="Age">Age</option>
                <option value="companyName">Company Name</option>
            </select>
            <div id="age" style="display: none;">
                <input type="text" name="Age_" id="Age" placeholder="Enter your age"> 
            </div>
            <div id="companyname" style="display: none;">
                <input type="text" name="Company_Name" id="companyName" placeholder="Enter your Company Name:">
            </div>
            <div>
                <input type="submit" value="Sign up" name="submit">
            </div>
        </form>
    </div>
</body>


</html>


